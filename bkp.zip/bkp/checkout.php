<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
</head>
<body>
    <h1>Checkout</h1>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
            echo "<table border='1'>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                    </tr>";
            $total = 0;
            foreach ($_SESSION['cart'] as $item) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($item['product']) . "</td>";
                echo "<td>" . htmlspecialchars($item['quantity']) . "</td>";
                echo "<td>" . htmlspecialchars($item['price']) . "</td>";
                echo "</tr>";
                $total += $item['quantity'] * $item['price'];
            }
            echo "</table>";
            echo "<h2>Total: $" . htmlspecialchars($total) . "</h2>";
        } else {
            echo "<p>Your cart is empty.</p>";
        }
    } else {
        echo "<p>No data received.</p>";
    }
    ?>
</body>
</html>
