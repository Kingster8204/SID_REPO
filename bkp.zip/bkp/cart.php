<?php
session_start();
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['product']) &&
    isset($_GET['quantity']) && isset($_GET['price'])) {
    $product = $_GET['product'];
    $quantity = $_GET['quantity'];
    $price = $_GET['price'];
    
    // Check if the item already exists in the cart
    $exists = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['product'] == $product) {
            $item['quantity'] += $quantity; // Update quantity
            $exists = true;
            break;
        }
    }
    if (!$exists) {
        // Store new item in session
        $item = array("product" => $product, "quantity" => $quantity, "price" => $price);
        array_push($_SESSION['cart'], $item);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shopping Cart</title>
</head>
<body>
    <h1>Your Cart</h1>
    <table border="1">
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
        </tr>
        <?php
        $total = 0;
        foreach ($_SESSION['cart'] as $item) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($item['product']) . "</td>";
            echo "<td>" . htmlspecialchars($item['quantity']) . "</td>";
            echo "<td>" . htmlspecialchars($item['price']) . "</td>";
            echo "</tr>";
            $total += $item['quantity'] * $item['price'];
        }
        ?>
    </table>
    <h2>Total: $<?php echo htmlspecialchars($total); ?></h2>
    <form action="checkout.php" method="POST">
        <input type="submit" value="Proceed to Checkout">
    </form>
</body>
</html>
